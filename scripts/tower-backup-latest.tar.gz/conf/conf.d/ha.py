
# The system UUID, as captured by Ansible.
SYSTEM_UUID = '375a15c0-09e0-4f27-8d71-e6013e743935'
